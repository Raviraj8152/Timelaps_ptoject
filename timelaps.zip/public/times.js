const fs = require('fs');
const { exec } = require('child_process');

const inputDir = 'C:/Users/Raviraj/Pictures/images/'; // path to input directory containing images
const outputDir = 'C:/Users/Raviraj/Pictures/images/'; // path to output directory for generated video

// Check if output directory exists, create it if it doesn't
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

// Set framerate and output filename
const fps = 30;
const outputFilename = 'timelapse.mp4';

// Get list of image files in input directory
fs.readdir(inputDir, (err, files) => {
  if (err) {
    console.error(`Error reading directory: ${err}`);
    return;
  }

  // Filter out non-image files
  const imageFiles = files.filter((file) => {
    return /\.(gif|jpe?g|png|webp)$/i.test(file);
  });

  // Sort image files in ascending order
  imageFiles.sort();

  // Build input file list for ffmpeg command
  const inputFiles = imageFiles.map((file) => {
    return `${inputDir}/${file}`;
  }).join('|');

  // Build ffmpeg command to generate time-lapse video
  const ffmpegCommand = `ffmpeg -framerate ${fps} -i "concat:${inputFiles}" -c:v libx264 -preset slow -crf 18 -pix_fmt yuv420p ${outputDir}/${outputFilename}`;

  // Run ffmpeg command
  exec(ffmpegCommand, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error running ffmpeg: ${error}`);
      return;
    }

    console.log(`Time-lapse video generated: ${outputDir}/${outputFilename}`);
  });
});
